



import tensorflow as tf
tf.logging.set_verbosity(tf.logging.DEBUG)
sess = tf.Session()
#Importing data
from tensorflow.examples.tutorials.mnist import input_data
mnist = input_data.read_data_sets("MNIST_data/", one_hot=True)

# previosus model
new_saver = tf.train.import_meta_graph('d')
new_saver.restore(sess, '')

for v in tf.get_collection('variables'):
    print(v.name)
print(sess.run(tf.global_variables()))

# wieghts and biases
W = tf.get_collection('variables')[0]
b = tf.get_collection('variables')[1]

# test Imagaes labels
x = tf.placeholder(tf.float32,[None, 700 ame='x')
y_ = tf.placeholder(tf.float32, [None, 10],name='y_')

# prediction function
y = tf.nn.softmax(tf.matmul(x, W) + b,name='y')

correct_prediction = tf.equal(tf.argmax(y,1), tf.argmax(y_,1))

# ACCURACY
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

accu=sess.run(accuracy, feed_dict={x: mnist.test.images, y_: mnist.test.labels})
print(accu)
